# Play & Ganhe
Protótipo Android com jogos simples e moedas demonstrativas. Não realiza pagamentos reais.
